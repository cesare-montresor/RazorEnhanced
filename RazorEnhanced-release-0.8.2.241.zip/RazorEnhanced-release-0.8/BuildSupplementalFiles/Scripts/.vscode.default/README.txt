Copy the folder and rename it ".vscode", is intended to be placed inside Scripts/
If you already have it, you can check for differences between you and this settings.json

