## Dalamar:
## This file is intended to be empty to facilitate the use of external editors.
## The following syntax is now valid, when run inside RE:
## from AutoComplete import *
## 
## If you look for the actual typing file, you should look inside: <RE_Root>/Config/AutoComplete.py
## <RE_Root>/Config/AutoComplete.py is automatially generated when RE first run.
## To override it place a custom copy inside Data/
## <RE_Root>/Data/AutoComplete.py