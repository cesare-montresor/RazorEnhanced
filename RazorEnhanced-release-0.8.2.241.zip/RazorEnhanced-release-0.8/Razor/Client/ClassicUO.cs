using Assistant.UI;
using CUO_API;
using RazorEnhanced;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Threading;
using System.Windows.Forms;


namespace Assistant
{
    public partial class Engine
    {

        public static unsafe void Install(PluginHeader* plugin)
        {
            AppDomain.CurrentDomain.AssemblyResolve += (sender, e) =>
            {
                string[] fields = e.Name.Split(',');
                string name = fields[0];
                string culture = fields[2];

                if (name.EndsWith(".resources") && !culture.EndsWith("neutral"))
                {
                    return null;
                }

                AssemblyName askedassembly = new(e.Name);

                bool isdll = File.Exists(Path.Combine(RootPath, askedassembly.Name + ".dll"));

                return Assembly.LoadFile(Path.Combine(RootPath, askedassembly.Name + (isdll ? ".dll" : ".exe")));
            };


            //ClassicUO.Configuration.Settings settings = ClassicUO.Configuration.Settings.Get();
            Install2(plugin);
        }

        public static unsafe void Install2(PluginHeader* plugin)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            //SplashScreen.Start();
            m_ActiveWnd = SplashScreen.Instance;

            ClassicUOClient.UOFilePath =
                ((OnGetUOFilePath)Marshal.GetDelegateForFunctionPointer(plugin->GetUOFilePath, typeof(OnGetUOFilePath))
                )();

            ClassicUOClient cuo = new();
            Client.Instance = cuo;
            cuo.InitPlugin(plugin);

            cuo.RunUI();
        }

    }
    public class ClassicUOClient : Client
    {
        public static string UOFilePath { get; set; }
        public override Process ClientProcess => m_ClientProcess;
        public override bool ClientRunning => m_ClientRunning;
        private uint m_In, m_Out;

        private readonly Process m_ClientProcess = null;
        private bool m_ClientRunning = false;
        private Version m_ClientVersion;

        private static OnPacketSendRecv _sendToClient, _sendToServer, _recv, _send;
        private static OnGetPacketLength _getPacketLength;
        private static OnGetPlayerPosition _getPlayerPosition;
        private static OnCastSpell _castSpell;
        private static OnGetStaticImage _getStaticImage;
        private static OnTick _tick;
        private static RequestMove _requestMove;
        private static OnSetTitle _setTitle;
        private static OnGetUOFilePath _uoFilePath;


        private static OnHotkey _onHotkeyPressed;
        private static OnMouse _onMouse;
        private static OnUpdatePlayerPosition _onUpdatePlayerPosition;
        private static OnClientClose _onClientClose;
        private static OnInitialize _onInitialize;
        private static OnConnected _onConnected;
        private static OnDisconnected _onDisconnected;
        private static OnFocusGained _onFocusGained;
        private static OnFocusLost _onFocusLost;
        private IntPtr m_ClientWindow;
        private static bool m_Ready = false;

        static ClassicUOClient()
        {
            Client.IsOSI = false;
            string server = RazorEnhanced.CUO.GetSetting("IP");
            IPAddress address = Dns.GetHostAddresses(server)[0];
            m_LastConnection = address;
        }

        internal override bool Init(RazorEnhanced.Shard selected)
        {

            base.Init(selected);

            // Spin up CUO
            Process cuo = new();
            cuo.StartInfo.FileName = selected.CUOClient;
            cuo.StartInfo.WorkingDirectory = Path.GetDirectoryName(selected.CUOClient);
            int osiEnc = 0;
            if (selected.OSIEnc)
            {
                osiEnc = 5;
            }
            if (File.Exists(selected.ClientPath))
            {
                var clientVersion = FileVersionInfo.GetVersionInfo(selected.ClientPath);
                string verString = String.Format("{0:00}.{1:0}.{2:0}.{3:D1}", clientVersion.FileMajorPart, clientVersion.FileMinorPart, clientVersion.FileBuildPart, clientVersion.FilePrivatePart);
                cuo.StartInfo.Arguments = String.Format("-ip {0} -port {1} -uopath \"{2}\" -no_server_ping -encryption {3} -plugins \"{4}\" -clientversion \"{5}\"",
                                            selected.Host, selected.Port, ShortFileName(selected.ClientFolder), osiEnc,
                                            ShortFileName(System.Reflection.Assembly.GetExecutingAssembly().Location),
                                            verString);
            }
            else
            {
                cuo.StartInfo.Arguments = String.Format("-ip {0} -port {1} -uopath \"{2}\" -no_server_ping -encryption {3} -plugins \"{4}\"",
                                            selected.Host, selected.Port, ShortFileName(selected.ClientFolder), osiEnc,
                                            ShortFileName(System.Reflection.Assembly.GetExecutingAssembly().Location)
                                            );
            }
            cuo.Start();
            m_Running = false;
            return false;

        }


        public override void SetMapWndHandle(Form mapWnd)
        {
        }

        public override void RequestStatbarPatch(bool preAOS)
        {
        }

        public override void SetCustomNotoHue(int hue)
        {
        }

        public override void SetSmartCPU(bool enabled)
        {
        }

        public override void SetGameSize(int x, int y)
        {
        }

        public override Loader_Error LaunchClient(string client)
        {
            return Loader_Error.SUCCESS;
        }

        public override bool ClientEncrypted { get; set; }

        public override bool ServerEncrypted { get; set; }

        public static Assembly CUOAssembly { get { return System.Reflection.Assembly.GetEntryAssembly(); } }
        public static Queue<Action> CUOActionQueue { get; set; } = new Queue<Action>();

        public unsafe bool InitPlugin(PluginHeader* header)
        {
            _sendToClient =
                (OnPacketSendRecv)Marshal.GetDelegateForFunctionPointer(header->Recv, typeof(OnPacketSendRecv));
            _sendToServer =
                (OnPacketSendRecv)Marshal.GetDelegateForFunctionPointer(header->Send, typeof(OnPacketSendRecv));
            _getPacketLength =
                (OnGetPacketLength)Marshal.GetDelegateForFunctionPointer(header->GetPacketLength,
                    typeof(OnGetPacketLength));
            _getPlayerPosition =
                (OnGetPlayerPosition)Marshal.GetDelegateForFunctionPointer(header->GetPlayerPosition,
                    typeof(OnGetPlayerPosition));
            _castSpell = (OnCastSpell)Marshal.GetDelegateForFunctionPointer(header->CastSpell, typeof(OnCastSpell));
            _getStaticImage =
                (OnGetStaticImage)Marshal.GetDelegateForFunctionPointer(header->GetStaticImage,
                    typeof(OnGetStaticImage));
            _requestMove =
                (RequestMove)Marshal.GetDelegateForFunctionPointer(header->RequestMove, typeof(RequestMove));
            _setTitle = (OnSetTitle)Marshal.GetDelegateForFunctionPointer(header->SetTitle, typeof(OnSetTitle));
            _uoFilePath =
                (OnGetUOFilePath)Marshal.GetDelegateForFunctionPointer(header->GetUOFilePath, typeof(OnGetUOFilePath));
            m_ClientVersion = new Version((byte)(header->ClientVersion >> 24), (byte)(header->ClientVersion >> 16),
                (byte)(header->ClientVersion >> 8), (byte)header->ClientVersion);
            m_ClientRunning = true;
            m_ClientWindow = header->HWND;
            _tick = Tick;
            _recv = OnRecv;
            _send = OnSend;
            _onHotkeyPressed = OnHotKeyHandler;
            _onMouse = OnMouseHandler;
            _onUpdatePlayerPosition = OnPlayerPositionChanged;
            _onClientClose = OnClientClosing;
            _onInitialize = OnInitialize;
            _onConnected = OnConnected;
            _onDisconnected = OnDisconnected;
            _onFocusGained = OnFocusGained;
            _onFocusLost = OnFocusLost;
            header->Tick = Marshal.GetFunctionPointerForDelegate(_tick);
            header->OnRecv = Marshal.GetFunctionPointerForDelegate(_recv);
            header->OnSend = Marshal.GetFunctionPointerForDelegate(_send);
            header->OnHotkeyPressed = Marshal.GetFunctionPointerForDelegate(_onHotkeyPressed);
            header->OnMouse = Marshal.GetFunctionPointerForDelegate(_onMouse);
            header->OnPlayerPositionChanged = Marshal.GetFunctionPointerForDelegate(_onUpdatePlayerPosition);
            header->OnClientClosing = Marshal.GetFunctionPointerForDelegate(_onClientClose);
            header->OnInitialize = Marshal.GetFunctionPointerForDelegate(_onInitialize);
            header->OnConnected = Marshal.GetFunctionPointerForDelegate(_onConnected);
            header->OnDisconnected = Marshal.GetFunctionPointerForDelegate(_onDisconnected);
            header->OnFocusGained = Marshal.GetFunctionPointerForDelegate(_onFocusGained);
            header->OnFocusLost = Marshal.GetFunctionPointerForDelegate(_onFocusLost);

            RazorEnhanced.Shard fake_shard =
                new("Classic UO Default", Path.Combine(ClassicUOClient.UOFilePath, "client.exe"),
                                        ClassicUOClient.UOFilePath, "", "127.0.0.1", 1000, true, false, true);
            base.Init(fake_shard);
            RazorEnhanced.Settings.Load(RazorEnhanced.Profiles.LastUsed());
            Start(fake_shard);
            m_Ready = true;
            return true;
        }

        public unsafe override bool InstallHooks(IntPtr pluginPtr)
        {
            //Engine.MainWindow.SafeAction((s) => { Engine.MainWindow.MainForm_EndLoad(); });
            return true;
        }

        private void Tick()
        {
            Timer.Slice();

            while (CUOActionQueue.Count > 0)
            {
                Action action = CUOActionQueue.Dequeue();
                action?.Invoke();
            }
        }

        private void OnPlayerPositionChanged(int x, int y, int z)
        {
            if (World.Player != null)
            {
                World.Player.Position = new Point3D(x, y, z);
                World.Player.WalkScriptRequest = 2;
            }
        }

        internal static void RunTheUI()
        {
            AutoDocIO.UpdateDocs();
            Engine.MainWnd = new MainForm();
            if (!IsOSI)
            {
                Engine.MainWindow.SafeAction(s => { s.DisableRecorder(); });
                Engine.MainWindow.SafeAction(s => { s.DisableSmartCpu(); });
                Engine.MainWindow.SafeAction(s => { s.DisableGameSize(); });
            }
            Application.Run(Engine.MainWnd);
        }
        public override void RunUI()
        {
            Thread t = new(() => { RunTheUI(); });
            t.SetApartmentState(ApartmentState.STA);
            t.IsBackground = true;
            t.Start();
        }
        internal override void SelectedShard(RazorEnhanced.Shard shard)
        {
            return;
        }

        private unsafe bool OnRecv(ref byte[] data, ref int length)
        {
            bool result = true;
            try
            {
                m_In += (uint)length;
                fixed (byte* ptr = data)
                {
                    byte id = data[0];

                    PacketReader reader = null;
                    Packet packet = null;
                    bool isView = PacketHandler.HasServerViewer(id);
                    bool isFilter = PacketHandler.HasServerFilter(id);


                    if (isView)
                    {

                        reader = new PacketReader(ptr, length, PacketsTable.IsDynLength(id));
                        result = !PacketHandler.OnServerPacket(id, reader, packet);
                    }
                    else if (isFilter)
                    {
                        packet = new Packet(data, length, PacketsTable.IsDynLength(id));
                        result = !PacketHandler.OnServerPacket(id, reader, packet);
                    }
                    //TODO: check if this is done correctly
                    PacketLogger.SharedInstance.LogPacketData(PacketPath.ServerToClient, data, result);
                }
            }
            catch (Exception e)
            {
                Utility.Logger.Debug("{0} crash in onRecv {1}", System.Reflection.MethodBase.GetCurrentMethod().Name, e.ToString());
            }
            return result;
        }

        private unsafe bool OnSend(ref byte[] data, ref int length)
        {
            m_Out += (uint)length;
            fixed (byte* ptr = data)
            {
                bool result = true;
                byte id = data[0];

                PacketReader reader = null;
                Packet packet = null;
                bool isView = PacketHandler.HasClientViewer(id);
                bool isFilter = PacketHandler.HasClientFilter(id);

                if (isView)
                {
                    reader = new PacketReader(ptr, length, PacketsTable.IsDynLength(id));
                    result = !PacketHandler.OnClientPacket(id, reader, packet);
                }
                else if (isFilter)
                {
                    packet = new Packet(data, length, PacketsTable.IsDynLength(id));
                    result = !PacketHandler.OnClientPacket(id, reader, packet);
                }
                //TODO: check if this is done correctly
                PacketLogger.SharedInstance.LogPacketData(PacketPath.ClientToServer, data, result);
                return result;
            }
        }

        private void OnMouseHandler(int button, int wheel)
        {
            if (button > 4)
                button = 3;
            else if (button > 3)
                button = 2;
            else if (button > 2)
                button = 2;
            else if (button > 1)
                button = 1;

            RazorEnhanced.HotKey.OnMouse(button, wheel);
        }

        private enum SDL_Keymod
        {
            KMOD_NONE = 0x0000,
            KMOD_LSHIFT = 0x0001,
            KMOD_RSHIFT = 0x0002,
            KMOD_LCTRL = 0x0040,
            KMOD_RCTRL = 0x0080,
            KMOD_LALT = 0x0100,
            KMOD_RALT = 0x0200,
            KMOD_LGUI = 0x0400,
            KMOD_RGUI = 0x0800,
            KMOD_NUM = 0x1000,
            KMOD_CAPS = 0x2000,
            KMOD_MODE = 0x4000,
            KMOD_RESERVED = 0x8000
        }

        private enum SDL_Keycode_Ignore
        {
            SDLK_LCTRL = 1073742048,
            SDLK_LSHIFT = 1073742049,
            SDLK_LALT = 1073742050,
            SDLK_RCTRL = 1073742052,
            SDLK_RSHIFT = 1073742053,
            SDLK_RALT = 1073742054,
        }

        // Weird situation where CUO was passing in a wrong value
        // for oem keys.
        // so, I special case those, check if down, and return appropriate
        // code
        internal int checkForOmeKeys(int key)
        {
            Keys[] oemKeys = {Keys.Oem1, Keys.Oem102, Keys.Oem2,
            Keys.Oem3, Keys.Oem4, Keys.Oem5, Keys.Oem6, Keys.Oem7, Keys.Oem8,
            Keys.OemBackslash, Keys.OemClear, Keys.OemCloseBrackets,
            Keys.Oemcomma, Keys.OemMinus, Keys.OemOpenBrackets,
            Keys.OemPeriod, Keys.OemPipe, Keys.Oemplus, Keys.OemQuestion,
            Keys.OemQuotes, Keys.OemSemicolon, Keys.Oemtilde };
            foreach (var oemKey in oemKeys)
            {
                if ((Platform.GetAsyncKeyState((int)oemKey) & 0xFF00) != 0)
                    return (int)oemKey;
            }
            return key;
        }

        private bool OnHotKeyHandler(int inkey, int mod, bool ispressed)
        {
            int key = checkForOmeKeys(inkey);
            if (ispressed && !Enum.IsDefined(typeof(SDL_Keycode_Ignore), key))
            {
                RazorEnhanced.ModKeys cur = RazorEnhanced.ModKeys.None;
                SDL_Keymod keymod = (SDL_Keymod)mod;
                if (keymod.HasFlag(SDL_Keymod.KMOD_LCTRL) || keymod.HasFlag(SDL_Keymod.KMOD_RCTRL))
                    cur |= RazorEnhanced.ModKeys.Control;
                if (keymod.HasFlag(SDL_Keymod.KMOD_LALT) || keymod.HasFlag(SDL_Keymod.KMOD_RALT))
                    cur |= RazorEnhanced.ModKeys.Alt;
                if (keymod.HasFlag(SDL_Keymod.KMOD_LSHIFT) || keymod.HasFlag(SDL_Keymod.KMOD_RSHIFT))
                    cur |= RazorEnhanced.ModKeys.Shift;

                if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                    return RazorEnhanced.HotKey.OnKeyDown(LinuxPlatform.MapKey(key), cur);
                return RazorEnhanced.HotKey.OnKeyDown(Win32Platform.MapKey(key), cur);
            }

            return true;
        }
        private void OnDisconnected()
        {
            base.OnDisconnected();
        }

        private void OnConnected()
        {
            base.OnConnected();
            bool ReWindowVisible = false;
            foreach (Screen screen in Screen.AllScreens)
            {
                System.Drawing.Rectangle screenArea = new(screen.Bounds.Location, screen.Bounds.Size);
                screenArea.Width -= (Engine.MainWindow.Width / 2);
                screenArea.Height -= (Engine.MainWindow.Height / 2);
                if (screenArea.Contains(Engine.MainWindow.Location))
                {
                    ReWindowVisible = true;
                }
            }
            if (!ReWindowVisible)
            {
                System.Drawing.Rectangle cuoWindow = Client.Instance.GetUoWindowPos();
                Engine.MainWindow.SafeAction(s => { s.Location = cuoWindow.Location; });
            }

            m_ConnectionStart = DateTime.UtcNow;
            m_LastConnection = Engine.IP;
        }

        private void OnClientClosing()
        {
            Close();
        }

        private void OnInitialize()
        {

        }

        public override void SetConnectionInfo(IPAddress addr, int port)
        {
        }

        public override void SetNegotiate(bool negotiate)
        {
        }

        public override bool Attach(int pid)
        {
            return false;
        }

        public override void Close()
        {
            base.Close();
        }

        public override void UpdateTitleBar()
        {
        }


        public override void SetTitleStr(string str)
        {
            //_setTitle(str);
        }

        public override bool OnMessage(MainForm razor, uint wParam, int lParam)
        {
            return false;
        }

        public override bool OnCopyData(IntPtr wparam, IntPtr lparam)
        {
            return false;
        }

        public override void SendToServer(Packet p)
        {
            byte[] data = p.Compile();
            int length = (int)p.Length;
            _sendToServer(ref data, ref length);
        }

        public override void SendToServer(PacketReader pr)
        {
            SendToServer(MakePacketFrom(pr));
        }

        public override void SendToClient(Packet p)
        {
            byte[] data = p.Compile();
            int length = (int)p.Length;

            _sendToClient(ref data, ref length);
        }

        public override void ForceSendToClient(Packet p)
        {
            byte[] data = p.Compile();
            int length = (int)p.Length;

            _sendToClient(ref data, ref length);
        }

        public override void ForceSendToServer(Packet p)
        {
            byte[] data = p.Compile();
            int length = (int)p.Length;

            _sendToServer(ref data, ref length);
        }

        public override void SetPosition(uint x, uint y, uint z, byte dir)
        {
        }

        public override string GetClientVersion()
        {
            return m_ClientVersion.ToString();
        }

        public override string GetUoFilePath()
        {
            return _uoFilePath();
        }

        public override IntPtr GetWindowHandle()
        {
            return m_ClientWindow;
        }

        public override uint TotalDataIn()
        {
            return m_In;
        }

        public override uint TotalDataOut()
        {
            return m_Out;
        }

        internal override bool RequestWalk(Direction m_Dir)
        {
            bool result = false;
            int MaxTries = 10;
            int Delay = 30;
            while (result == false)
            {
                MaxTries -= 1;
                result = _requestMove((int)m_Dir, false);
                if (result == false)
                    Thread.Sleep(Delay);
                if (MaxTries <= 0)
                    break;
            }
            return result;
        }
        internal override bool RequestRun(Direction m_Dir)
        {
            bool result = false;
            int MaxTries = 10;
            int Delay = 30;
            while (result == false)
            {
                MaxTries -= 1;
                result = _requestMove((int)m_Dir, true);
                if (result == false)
                    Thread.Sleep(Delay);
                if (MaxTries <= 0)
                    break;
            }
            return result;
        }
        public override void PathFindTo(Assistant.Point3D Location)
        {
            Assistant.Client.Instance.SendToClientWait(new PathFindTo(Location));
        }

        public void OnFocusGained()
        {
        }

        public void OnFocusLost()
        {
        }
        public override unsafe void SendToClientWait(Packet p)
        {
            SendToClient(p);
        }
        public override unsafe void SendToServerWait(Packet p)
        {
            SendToServer(p);
        }
        public override void BeginCalibratePosition()
        { }
        public override void InitSendFlush()
        { }
        public override bool Ready { get { return m_Ready; } }

        public override List<string> ValidFileLocations()
        {
            List<string> validFileLocations = new();
            validFileLocations.Add(Assistant.Engine.RootPath);
            validFileLocations.Add(Path.GetDirectoryName(CUOAssembly.Location));

            return validFileLocations;
        }
        public override int GetBuildPart()
        {
            return m_ClientVersion.Build;
        }

        public override int GetMajorPart()
        {
            return m_ClientVersion.Major;
        }

    }
}

