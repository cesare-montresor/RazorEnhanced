protoc --python_out=. your_proto_file.proto
#python -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. ProtoControl.proto
