protoc --python_out=. your_proto_file.proto
