using Assistant;
using Assistant.Enums;
using JsonData;
using System;
using System.Collections.Generic;
using System.Threading;

namespace RazorEnhanced
{
    /// <summary>
    /// The Target class provides various methods for targeting Land, Items and Mobiles in game.
    /// </summary>
    public class Target
    {
        private int m_ptarget;
        private RazorEnhanced.Point3D m_pgtarget;

        /// <summary>
        /// Get the status of the in-game target cursor
        /// Optionally specify the target flag and check if the cursor is "Beneficial", "Harmful", or "Neutral".
        /// </summary>
        /// <param name="targetFlag">The target flag to check for can be "Any", "Beneficial", "Harmful", or "Neutral".</param>
        /// <returns>True if the client has a target cursor and the optional flag matches; otherwise, false.</returns>
        public static bool HasTarget(string targetFlag = "Any")
        {
            if (!Assistant.Targeting.HasTarget)
            {
                return false;
            }

            TargetFlags flag = (TargetFlags)Assistant.Targeting.TargetFlags;

            switch (targetFlag.ToLower())
            {
                case "any":
                    return true;

                case "neutral":
                    return flag == TargetFlags.Neutral;

                case "harmful":
                    return flag == TargetFlags.Harmful;

                case "beneficial":
                    return flag == TargetFlags.Beneficial;

                default:
                    throw new ArgumentOutOfRangeException(nameof(targetFlag), targetFlag, "Invalid target flag specified.");
            }
        }

        /// <summary>
        /// Wait for the cursor to show the target, pause the script for a maximum amount of time. and optional flag True or False. True Not show cursor, false show it
        /// </summary>
        /// <param name="delay">Maximum amount to wait, in milliseconds</param>
        /// <param name="noshow">Pevent the cursor to display the target.</param>
        /// <returns></returns>
        public static bool WaitForTarget(int delay, bool noshow = false)
        {
            Assistant.Targeting.NoShowTarget = noshow;
            var watch = System.Diagnostics.Stopwatch.StartNew();
            while (Assistant.Targeting.HasTarget == false)
            {
                Thread.Sleep(2);
                if (watch.ElapsedMilliseconds >= delay)
                    break;
                var elapsedMs2 = watch.ElapsedMilliseconds;
            }
            watch.Stop();
            var elapsedMs = watch.ElapsedMilliseconds;
            Assistant.Targeting.NoShowTarget = false;
            return HasTarget();
        }

        /// <summary>
        /// Wait for the cursor to show the target, or the sound for fizzle (0x5c) or pause the script for a maximum amount of time. 
        /// and an optional flag True or False. True Not show cursor, false show it
        /// </summary>
        /// <param name="delay">Maximum amount to wait, in milliseconds</param>
        /// <param name="noshow">Prevent the cursor to display the target.</param>
        /// <returns></returns>

        public static bool WaitForTargetOrFizzle(int delay = 5000, bool noshow = false)
        {
            ManualResetEvent waitOrFizzleEvent = new(false);
            void watchForFizzle(PacketReader p, PacketHandlerEventArgs args)
            {
                waitOrFizzleEvent.Set();
            }
            PacketHandler.RegisterServerToClientViewer(0x54, watchForFizzle);
            waitOrFizzleEvent.WaitOne(delay);
            PacketHandler.RemoveServerToClientViewer(0x54, watchForFizzle);

            return HasTarget();
        }



        /// <summary>
        /// Execute target on specific serial, item, mobile, X Y Z point.
        /// </summary>
        /// <param name="x">X coordinate.</param>
        /// <param name="y">Y coordinate.</param>
        /// <param name="z">Z coordinate.</param>
        /// <param name="StaticID">ID of Land/Tile</param>
        public static void TargetExecute(int x, int y, int z, int StaticID)
        {
            Assistant.Point3D location = new(x, y, z);
            Assistant.Targeting.Target(location, StaticID, true);
        }

        public static void TargetExecute(int x, int y, int z)
        {
            Assistant.Point3D location = new(x, y, z);
            Assistant.Targeting.Target(location, true);
        }


        /// <param name="serial">Serial of the Target</param>
        public static void TargetExecute(int serial)
        {
            if (!CheckHealPoisonTarg(serial))
            {
                Assistant.Targeting.Target(serial, true);
            }
        }

        /// <summary>
        /// Targets the Mobil or Item specified
        /// </summary>       
        /// <param name="entity">object can be a Mobil or an Item.</param>
        public static void TargetExecute(Assistant.UOEntity entity)
        {
            Assistant.Targeting.Target(entity.Serial.Value, true);
        }


        /// <summary>
        /// Targets the entity of a specific Graphic.
        /// </summary>
        /// <param name="graphic">Graphic of an Entity.</param>
        /// <param name="color">Color of an Entity. (default: -1)</param>
        /// <param name="range">Range to scan for an Entity. (default: 20)</param>
        /// <param name="selector">Selector for sorting the Entity. (default: Nearest)</param>
        /// <param name="notoriety">Notorieties of an Entity. (default: None -> all)</param>
        /// <returns>if the attack was achieved. (true: target succeeded)</returns>
        public static bool TargetType(int graphic, int color = -1, int range = 20, string selector = "Nearest", List<byte> notoriety = null)
        {
            Item itm = null;
            // Container (Range: Container Serial)
            itm = Items.FindByID(graphic, color, Player.Backpack.Serial, range);

            if (itm != null)
            {
                TargetExecute(itm);
                return true;
            }
            else
            {
                var options = new Items.Filter();
                options.Graphics.Add(graphic);
                if (color != -1)
                    options.Hues.Add(color);
                options.RangeMin = -1;
                options.RangeMax = range;
                options.OnGround = 1;

                var item_list = Items.ApplyFilter(options);

                itm = Items.Select(item_list, selector);
            }

            if (itm == null)
            {
                Mobile mob = null;
                // Container (Range: Container Serial)
                var options = new Mobiles.Filter();

                options.Bodies.Add(graphic);
                if (color != -1)
                    options.Hues.Add(color);

                if (notoriety != null && notoriety.Count > 0)
                {
                    foreach (byte i in notoriety)
                    {
                        if (i >= 1 && i < 7)
                            options.Notorieties.Add(i);
                    }
                }

                options.RangeMin = -1;
                options.RangeMax = range;

                var mob_list = Mobiles.ApplyFilter(options);

                mob = Mobiles.Select(mob_list, selector);

                if (mob != null)
                {
                    TargetExecute(mob);
                    return true;
                }
            }
            else
            {
                TargetExecute(itm);
                return true;
            }

            return false;
        }

        static internal HashSet<int> CaveTiles = new() { 0xae, 0x5, 0x3, 0xc1, 0xc2, 0xc3, 0xbd, 0x0016, 0x0017, 0x0018, 0x0019,
            0x244, 0x245, 0x246, 0x247, 0x248, 0x249, 0x22b, 0x22c, 0x22d, 0x22e, 0x22f,
            0x053B, 0x053C, 0x053D, 0x053E, 0x053f };
        //static internal HashSet<int> SoilTiles = new HashSet<int>() {0x73, 0x74, 0x75, 0x76,  0x77, 0x78};

        /// <summary>
        /// Execute target on specific land point with offset distance from Mobile. Distance is calculated by target Mobile.Direction.
        /// </summary>
        /// <param name="mobile">Mobile object to target.</param>
        /// <param name="offset">Distance from the target.</param>
        public static void TargetExecuteRelative(Mobile mobile, int offset)
        {
            Assistant.Point2D relpos = new();
            switch (mobile.Direction)
            {
                case "North":
                    relpos.X = mobile.Position.X;
                    relpos.Y = mobile.Position.Y - offset;
                    break;
                case "South":
                    relpos.X = mobile.Position.X;
                    relpos.Y = mobile.Position.Y + offset;
                    break;
                case "West":
                    relpos.X = mobile.Position.X - offset;
                    relpos.Y = mobile.Position.Y;
                    break;
                case "East":
                    relpos.X = mobile.Position.X + offset;
                    relpos.Y = mobile.Position.Y;
                    break;
                case "Up":
                    relpos.X = mobile.Position.X - offset;
                    relpos.Y = mobile.Position.Y - offset;
                    break;
                case "Down":
                    relpos.X = mobile.Position.X + offset;
                    relpos.Y = mobile.Position.Y + offset;
                    break;
                case "Left":
                    relpos.X = mobile.Position.X - offset;
                    relpos.Y = mobile.Position.Y + offset;
                    break;
                case "Right":
                    relpos.X = mobile.Position.X + offset;
                    relpos.Y = mobile.Position.Y - offset;
                    break;
            }
            var landId = Statics.GetLandID(relpos.X, relpos.Y, Player.Map);
            var tileinfo = Statics.GetStaticsLandInfo(relpos.X, relpos.Y, Player.Map);
            var tiles = Statics.GetStaticsTileInfo(relpos.X, relpos.Y, Player.Map);
            if (CaveTiles.Contains(tileinfo.StaticID))
            {
                if (tiles.Count > 0)
                {
                    Target.TargetExecute(relpos.X, relpos.Y, tiles[0].StaticZ, tiles[0].StaticID);
                    return;
                }

                var i = World.FindItems(relpos.X, relpos.Y, tileinfo.StaticZ);
                foreach (var item in i)
                {
                    if (CaveTiles.Contains(item.TypeID))
                    {
                        Target.TargetExecute(item.Serial);
                        return;
                    }
                }
            }

            Target.TargetExecute(relpos.X, relpos.Y, tileinfo.StaticZ);
            //Assistant.Point3D location = new Assistant.Point3D(relpos.X, relpos.Y, Statics.GetLandZ(relpos.X, relpos.Y, Player.Map));
            //Assistant.Targeting.Target(location, true);

        }
        /// <param name="serial">Serial of the mobile</param>
        /// <param name="offset">+- distance to offset from the mobile identified with serial</param>
        public static void TargetExecuteRelative(int serial, int offset)
        {
            Mobile m = Mobiles.FindBySerial(serial);
            if (m != null)
                TargetExecuteRelative(m, offset);
        }

        /// <summary>
        /// Find and target a resource using the specified item.
        /// </summary>
        /// <param name="item_serial">Item object to use.</param>
        /// <param name="resource_number"> Resource as standard name or custom number
        ///     0: ore
        ///     1: sand
        ///     2: wood
        ///     3: graves
        ///     4: red_mushrooms
        ///     n: custom 
        /// </param>
        public static void TargetResource(int item_serial, int resource_number)
        {
            Assistant.Item item = Assistant.World.FindItem(item_serial);
            if (item == null)
            {
                Scripts.SendMessageScriptError("Script Error: UseItem: Invalid Use Serial");
                return;
            }
            Client.Instance.SendToServer(new TargeByResource((uint)item_serial, (uint)resource_number));
        }

        public static void TargetResource(int item_serial, string resource_name)
        {
            Assistant.Item item = Assistant.World.FindItem(item_serial);
            if (item == null)
            {
                Scripts.SendMessageScriptError("Script Error: UseItem: Invalid Use Serial");
                return;
            }

            int number;
            switch (resource_name)
            {
                case "ore":
                    number = 0;
                    break;
                case "sand":
                    number = 1;
                    break;
                case "wood":
                    number = 2;
                    break;
                case "graves":
                    number = 3;
                    break;
                case "red_mushroom":
                    number = 4;
                    break;
                default:
                    System.Int32.TryParse(resource_name, out number);
                    break;
            }
            if (number >= 0)
                TargetResource(item_serial, number);
            else
                Misc.SendMessage("Valid resource types are ore, sand, wood, graves, red mushroom, or a number");
        }

        /// <param name="item">Item object to use.</param>
        /// <param name="resouce_name">name of the resource to be targeted. ore, sand, wood, graves, red mushroom</param>
        public static void TargetResource(Item item, string resouce_name)
        {
            TargetResource(item.Serial, resouce_name);
        }


        public static void TargetResource(Item item, int resoruce_number)
        {
            TargetResource(item.Serial, resoruce_number);
        }

        /// <summary>
        /// Cancel the current target.
        /// </summary>
        public static void Cancel()
        {
            //Assistant.Targeting.CancelClientTarget(true);
            Assistant.Targeting.CancelOneTimeTarget(true);
        }

        /// <summary>
        /// Execute the target on the Player.
        /// </summary>
        public static void Self()
        {
            if (World.Player != null)
                Assistant.Targeting.TargetSelf(false);
        }

        /// <summary>
        /// Enqueue the next target on the Player.
        /// </summary>
        public static void SelfQueued()
        {
            Assistant.Targeting.TargetSelf(true);
        }

        /// <summary>
        /// Execute the target on the last Item or Mobile targeted.
        /// </summary>
        public static void Last()
        {
            if (!CheckHealPoisonTarg(GetLast()))
                Assistant.Targeting.LastTarget();
        }

        /// <summary>
        /// Enqueue the next target on the last Item or Mobile targeted.
        /// </summary>
        public static void LastQueued()
        {
            Assistant.Targeting.LastTarget(true);
        }

        /// <summary>
        /// Returns the serial of last object used by the player.
        /// </summary>
        public static int LastUsedObject()
        {
            if (World.Player == null || World.Player.LastObject == 0)
                return -1;
            return World.Player.LastObject;
        }


        /// <summary>
        /// Get serial number of last target
        /// </summary>
        /// <returns>Serial as number.</returns>
        public static int GetLast()
        {
            return (int)Assistant.Targeting.GetLastTarger;
        }

        /// <summary>
        /// Get serial number of last attack target
        /// </summary>
        /// <returns>Serial as number.</returns>
        public static int GetLastAttack()
        {
            return (int)Assistant.Targeting.LastAttack;
        }

        public static void SetLast(RazorEnhanced.Mobile mob)
        {
            Assistant.Mobile mobile = World.FindMobile(mob.Serial);
            if (mobile != null)
                SetLast(mob.Serial);
        }

        /// <summary>
        /// Set the last target to specific mobile, using the serial.
        /// </summary>
        /// <param name="serial">Serial of the Mobile.</param>
        /// <param name="wait">Wait confirmation from the server.</param>
        public static void SetLast(int serial, bool wait = true)
        {
            TargetMessage(serial, wait); // Process message for highlight
            Assistant.Targeting.SetLastTarget(serial, 0, wait);
        }

        /// <summary>
        /// Clear the last attacked target
        /// </summary>
        public static void ClearLastAttack()
        {
            Assistant.Targeting.LastAttack = 0;
        }

        /// <summary>
        /// Clear Queue Target.
        /// </summary>
        public static void ClearQueue()
        {
            Assistant.Targeting.ClearQueue();
        }

        /// <summary>
        /// Clear the last target.
        /// </summary>
        public static void ClearLast()
        {
            Assistant.Targeting.ClearLast();
        }

        /// <summary>
        /// Clear last target and target queue.
        /// </summary>
        public static void ClearLastandQueue()
        {
            Assistant.Targeting.ClearQueue();
            Assistant.Targeting.ClearLast();
        }

        /// <summary>
        /// Prompt a target in-game, wait for the Player to select an Item or a Mobile. Can also specific a text message for prompt.
        /// </summary>
        /// <param name="message">Hint on what to select.</param>
        /// <param name="color">Color of the message. (default: 945, gray)</param>
        /// <returns>Serial of the selected object.</returns>
        public int PromptTarget(string message = "Select Item or Mobile", int color = 945)
        {
            m_ptarget = -1;
            Misc.SendMessage(message, color, true);
            Targeting.OneTimeTarget(false, new Targeting.TargetResponseCallback(PromptTargetExex_Callback));

            while (!Targeting.HasTarget)
                Thread.Sleep(30);

            while (m_ptarget == -1 && Targeting.HasTarget)
                Thread.Sleep(30);

            Thread.Sleep(100);

            if (m_ptarget == -1)
                Misc.SendMessage("Prompt Target Cancelled", color, true);

            return m_ptarget;
        }

        private void PromptTargetExex_Callback(bool loc, Assistant.Serial serial, Assistant.Point3D pt, ushort itemid)
        {
            m_ptarget = serial;
        }
        /// <summary>
        /// Prompt a target in-game, wait for the Player to select the ground. Can also specific a text message for prompt.
        /// </summary>
        /// <param name="message">Hint on what to select.</param>
        /// <param name="color">Color of the message. (default: 945, gray)</param>
        /// <returns>A Point3D object, containing the X,Y,Z coordinate</returns>
        public Point3D PromptGroundTarget(string message = "Select Ground Position", int color = 945)
        {
            m_pgtarget = Point3D.MinusOne;

            Misc.SendMessage(message, color, true);
            Targeting.OneTimeTarget(true, new Targeting.TargetResponseCallback(PromptGroundTargetExex_Callback));

            while (!Targeting.HasTarget)
                Thread.Sleep(30);

            while (m_pgtarget.X == -1 && Targeting.HasTarget)
                Thread.Sleep(30);

            Thread.Sleep(100);

            if (m_pgtarget.X == -1)
                Misc.SendMessage("Prompt Gorund Target Cancelled", color, true);

            return m_pgtarget;
        }

        private void PromptGroundTargetExex_Callback(bool loc, Assistant.Serial serial, Assistant.Point3D pt, ushort itemid)
        {
            if (!loc)
            {
                Mobile target = Mobiles.FindBySerial(serial);
                if (target == null)
                {
                    m_pgtarget = Point3D.MinusOne;
                }
                else
                {
                    m_pgtarget = new RazorEnhanced.Point3D(target.Position);
                }
            }
            else
                m_pgtarget = new Point3D(pt.X, pt.Y, pt.Z);
        }

        // Check Poison
        private static bool CheckHealPoisonTarg(Assistant.Serial ser)
        {
            if (World.Player == null)
                return false;

            if (!RazorEnhanced.Settings.General.ReadBool("BlockHealPoison"))
                return false;

            if (ser.IsMobile && (World.Player.LastSpell == Spell.ToID(1, 4) || World.Player.LastSpell == Spell.ToID(4, 5) || World.Player.LastSpell == 202))
            {
                Assistant.Mobile m = World.FindMobile(ser);

                if (m != null && m.Poisoned)
                {
                    World.Player.SendMessage(MsgLevel.Warning, "Heal blocked, Target is poisoned!");
                    return true;
                }
                else if (m != null && m.Blessed)
                {
                    World.Player.SendMessage(MsgLevel.Warning, "Heal blocked, Target is mortelled!");
                    return true;
                }
                return false;
            }
            else
                return false;
        }

        // Funzioni target per richiamare i target della gui

        private static string GetPlayerName(int s)
        {
            Assistant.Mobile mob = World.FindMobile(s);
            return mob != null ? mob.Name : string.Empty;
        }

        private static readonly int[] m_NotoHues = new int[8]
        {
            1, // black     unused 0
            0x059, // blue      0x0059 1
            0x03F, // green     0x003F 2
            0x3B2, // greyish   0x03b2 3
            0x3B2, // grey         "   4
            0x090, // orange        0x0090 5
            0x022, // red       0x0022 6
            0x035, // yellow        0x0035 7
        };

        private static int GetPlayerColor(Mobile mob)
        {
            if (mob == null)
                return 0;

            return m_NotoHues[mob.Notoriety];
        }

        /// <summary>
        /// Set Last Target from GUI filter selector, in Targetting tab.
        /// </summary>
        /// <param name="target_name">Name of the target filter.</param>
        public static void SetLastTargetFromList(string target_name)
        {
            TargetGUI targetdata = Settings.Target.TargetRead(target_name);
            if (targetdata != null)
            {
                Mobiles.Filter filter = targetdata.TargetGuiObject.Filter.ToMobileFilter();
                string selector = targetdata.TargetGuiObject.Selector;

                List<Mobile> filterresult;
                filterresult = Mobiles.ApplyFilter(filter);

                Mobile mobtarget = Mobiles.Select(filterresult, selector);
                if (mobtarget == null)
                    return;

                RazorEnhanced.Target.SetLast(mobtarget);
            }
        }


        /// <summary>
        /// Get Mobile object from GUI filter selector, in Targetting tab.
        /// </summary>
        /// <param name="target_name">Name of the target filter.</param>
        /// <returns>Mobile object matching. None: not found</returns>
        public static Mobile GetTargetFromList(string target_name)
        {
            TargetGUI targetdata = Settings.Target.TargetRead(target_name);
            if (targetdata == null)
                return null;


            Mobiles.Filter filter = targetdata.TargetGuiObject.Filter.ToMobileFilter();
            string selector = targetdata.TargetGuiObject.Selector;

            List<Mobile> filterresult;
            filterresult = Mobiles.ApplyFilter(filter);

            Mobile mobtarget = Mobiles.Select(filterresult, selector);
            if (mobtarget == null)
                return null;

            return mobtarget;
        }

        internal static void SetLastTargetFromListHotKey(string targetid)
        {
            TargetGUI targetdata = Settings.Target.TargetRead(targetid);

            if (targetdata == null)
                return;

            Mobiles.Filter filter = targetdata.TargetGuiObject.Filter.ToMobileFilter();
            string selector = targetdata.TargetGuiObject.Selector;

            List<Mobile> filterresult;
            filterresult = Mobiles.ApplyFilter(filter);

            Mobile mobtarget = Mobiles.Select(filterresult, selector);

            if (mobtarget == null)
                return;

            TargetMessage(mobtarget.Serial, false); // Process message for highlight

            Assistant.Mobile mobile = World.FindMobile(mobtarget.Serial);
            if (mobile != null)
                Targeting.SetLastTarget(mobile.Serial, 0, false);
        }


        /// <summary>
        /// Execute Target from GUI filter selector, in Targetting tab.
        /// </summary>
        /// <param name="target_name">Name of the target filter.</param>
        public static void PerformTargetFromList(string target_name)
        {
            TargetGUI targetdata = Settings.Target.TargetRead(target_name);

            if (targetdata == null)
                return;

            Mobiles.Filter filter = targetdata.TargetGuiObject.Filter.ToMobileFilter();
            string selector = targetdata.TargetGuiObject.Selector;

            List<Mobile> filterresult;
            filterresult = Mobiles.ApplyFilter(filter);

            Mobile mobtarget = Mobiles.Select(filterresult, selector);

            if (mobtarget == null)
                return;

            TargetExecute(mobtarget.Serial);
            SetLast(mobtarget);
        }

        /// <summary>
        /// Attack Target from gui filter selector, in Targetting tab.
        /// </summary>
        /// <param name="target_name"></param>
        public static void AttackTargetFromList(string target_name)
        {
            TargetGUI targetdata = Settings.Target.TargetRead(target_name);

            if (targetdata == null)
                return;

            Mobiles.Filter filter = targetdata.TargetGuiObject.Filter.ToMobileFilter();
            string selector = targetdata.TargetGuiObject.Selector;

            List<Mobile> filterresult;
            filterresult = Mobiles.ApplyFilter(filter);

            Mobile mobtarget = Mobiles.Select(filterresult, selector);

            if (mobtarget == null)
                return;

            AttackMessage(mobtarget.Serial, true); // Process message for highlight
            if (Targeting.LastAttack != mobtarget.Serial)
            {
                Assistant.Client.Instance.SendToClientWait(new ChangeCombatant(mobtarget.Serial));
                Targeting.LastAttack = (uint)mobtarget.Serial;
            }
            Assistant.Client.Instance.SendToServerWait(new AttackReq(mobtarget.Serial)); // Real attack
        }

        internal static void TargetMessage(int serial, bool wait)
        {
            if (Assistant.Engine.MainWindow.ShowHeadTargetCheckBox.Checked)
            {
                if (Friend.IsFriend(serial))
                    Mobiles.Message(World.Player.Serial, 63, "Target: [" + GetPlayerName(serial) + "]", wait);
                else
                    Mobiles.Message(World.Player.Serial, GetPlayerColor(Mobiles.FindBySerial(serial)), "Target: [" + GetPlayerName(serial) + "]", wait);
            }

            if (Assistant.Engine.MainWindow.HighlightTargetCheckBox.Checked)
                Mobiles.Message(serial, 10, "* Target *", wait);
        }

        internal static void AttackMessage(int serial, bool wait)
        {
            if (Assistant.Engine.MainWindow.ShowHeadTargetCheckBox.Checked)
            {
                if (Friend.IsFriend(serial))
                    Mobiles.Message(World.Player.Serial, 63, "Attack: [" + GetPlayerName(serial) + "]", wait);
                else
                    Mobiles.Message(World.Player.Serial, GetPlayerColor(Mobiles.FindBySerial(serial)), "Attack: [" + GetPlayerName(serial) + "]", wait);
            }

            if (Assistant.Engine.MainWindow.HighlightTargetCheckBox.Checked)
                Mobiles.Message(serial, 10, "* Target *", wait);
        }

    }
}
