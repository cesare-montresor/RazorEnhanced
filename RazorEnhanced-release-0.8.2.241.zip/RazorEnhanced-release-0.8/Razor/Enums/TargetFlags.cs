namespace Assistant.Enums
{
    public enum TargetFlags : byte
    {
        Neutral,
        Harmful,
        Beneficial,
        Any,
    }
}
